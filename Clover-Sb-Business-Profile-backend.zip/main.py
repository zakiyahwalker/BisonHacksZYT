import os
import jstor

#get information for business profile
def getBusinessProf() 
    list_prof = [] 
    name = input("")   
    list_prof.append(name) 
    owner = input("") 
    list_prof.append(owner) 
    numemploy = input("") 
    list_prof.append(numemploy) 
    location = input ("") 
    list_prof.append(location) 
    industry = input ("")
    list_prof.apppend(industry)
return list_prof

#upload profile to be seen
def insertProf()
    insertName = list_prof[0]
    insertOwner = list_prof[1]
    insertnumemploy = list_prof[2]
    insertlocation = list_prof[3]
    insertindustry = list_prof[4]

#retrive picute
def getPic()
  script_dir = os.path.dirname(__file__)
  rel_path = "../images/"
  abs_file_path = os.path.join(script_dir, rel_path)
  current_file ="image" + str(X) +".png"
  file = open(abs_file_path+current_file,'r')